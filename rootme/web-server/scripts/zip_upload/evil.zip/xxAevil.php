<?php echo system('cat index.php'); ?>
